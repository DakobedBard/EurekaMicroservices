package com.example.movieratings;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieRatingsApplicationTests {

	@Test
	void contextLoads() {
	}

}
